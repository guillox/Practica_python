class Consultorio:
    # Esta clase basicamente maneja la informacion referida al consultorio
    # Coleccion de pacientes y odontologos, esta clase era OPCIONAL
	def __init__(self,odontologos, pacientes):
		self.odontologos = odontologos
		self.pacientes = pacientes
		
	def verificar_y_reservar_turno_disponible(self, dia, hora, odontologo, paciente):
		turno = odontologo.verificar_y_reservar_turno_disponible(dia,hora,paciente)
		if (turno == None):
			turno = odontologo.buscar_turno_disponible_mas_cercano(dia,hora)
		return turno
			

class Persona:
	# Se podria hacer una herencia ya que Odontologo y Paciente son Personas y comparten informacion y comportamiento en comun
	def __init__(self,nombre, nro_documento, telefono):
		self.nombre = nombre
		self.nro_documento = nro_documento
		self.telefono = telefono
	
	def get_nombre(self):
		return self.nombre

	
class Paciente (Persona):
	def __init__(self,nombre, nro_documento, telefono, obra_social, historia_clinica):
		# Llamo al contructor del padre para que inicialice los valores y no tenga que duplicar la informacion
		# Sin esto casi que no tendria sentido la jerarquia
		Persona.__init__(self,nombre, nro_documento, telefono)
		self.obra_social = obra_social
		# La historia clinica se puede inicializar tambien como una lista vacia
		self.historia_clinica = historia_clinica 
	
	def buscar_ultima_historia_clinica(self):
		if (len(self.historia_clinica)>0):
			return self.historia_clinica[len(self.historia_clinica)-1]
		else:
			return None
		
	
class Odontologo (Persona):
	def __init__(self,nombre, nro_documento, telefono, nro_matricula, turnos):
		#llamo al contructor del padre para que inicialice los valores y no tenga que duplicar la informacion
		#sin esto casi que no tendria sentido la jerarquia
		Persona.__init__(self,nombre, nro_documento, telefono)
		# Los turnos estan representados por un diccionario en donde la clave es la fecha y por cada fecha se tiene una lista de objetos turnos
		self.nro_matricula = nro_matricula
		# Los turnos se pueden inicializar tambien como una lista vacia
		self.turnos = turnos 
		
	def verificar_y_reservar_turno_disponible(self, dia, hora, paciente):
		turno_encontrado = None
		for turno in self.turnos[dia]:
			if (turno.get_hora() == hora and turno.esta_disponible()):				
				# Si el turno esta disponible, lo tomo
				turno.reservar(paciente)
				turno_encontrado = turno
		return turno_encontrado

	def buscar_turno_disponible_mas_cercano(self, dia, hora):
		# Inicializo en un numero alto
		hora_cercana = 24
		turno_cercano = None
		for turno in self.turnos[dia]:
			# Me guardo todos los turnos libres del dia pedido (si es que hay)
			# Tengo que buscar el minimo
			if (turno.esta_disponible()) and (abs(hora - turno.get_hora()) < hora_cercana):
				turno_cercano = turno
				hora_cercana = abs(hora - turno.get_hora())		
		return turno_cercano


class Turno:
	def __init__(self, hora):
		self.hora = hora
		# Un turno esta disponible por defecto
		self.disponible = True 
		self.paciente = None
	
	def esta_disponible(self):
		return self.disponible
		
	def get_hora(self):
		return self.hora
	
	def reservar(self,paciente):
		self.paciente = paciente
		self.disponible = False

		
class Historia_clinica:
	def __init__(self, fecha_atencion, atendido_por, descripcion):
		self.fecha_atencion = fecha_atencion
		# El odontologo que lo atendio puede ser externo asi que usamos un string en vez de una referencia a un objeto odontologo
		self.atendido_por = atendido_por
		self.descripcion = descripcion
		
	def get_datos(self):
		return "Fecha: " + self.fecha_atencion + " - Atendido por: " + self.atendido_por + " - Descripcion: " + self.descripcion

			
###### Lo que esta a continuacion NO habia que hacerlo, es solo para testear el codigo #############

# Cargo algun odontologo con sus turnos
turnos = {"4-7-13":[Turno(9), Turno(19), Turno(12)], "5-7-13": [Turno(19), Turno(21)]}
odontologo = Odontologo("Juan Perez", 123345, 4545552, 34453, turnos)

# Cargo pacientes con sus historias
historia1 = Historia_clinica("12-3-12","Molina","extraccion de muela")
historia2 = Historia_clinica("2-11-11","Suarez","protesis")
historia_clinica = [historia1,historia2]
paciente1 = Paciente("Pedro", 23453, "221-2321434", "obra 1", historia_clinica)

# Creo el consultorio con los odontologos y pacientes
consultorio = Consultorio([odontologo],[paciente1])


##### EJERCICIO 1 PEDIDO DE TURNO #######

# Pido un turno, y si esta disponible lo reservo
reserva = consultorio.verificar_y_reservar_turno_disponible("4-7-13", 9, odontologo, paciente1)
if (reserva <> None and not reserva.esta_disponible()):
	print "se reservo el turno"
else:
	print "el turno mas cercano es a las "+ str(reserva.get_hora())
	
# Al pedir nuevamente el mismo turno, nos devuelve el mas cercano (objeto turno)
# Si al objeto le pido la hora me da el de las 12hs
# Pido un turno, y si esta disponible lo reservo

reserva = consultorio.verificar_y_reservar_turno_disponible("4-7-13", 10, odontologo, paciente1)
if (reserva <> None and not reserva.esta_disponible()):
	print "se reservo el turno"
else:
	print "el turno mas cercano es a las "+ str(reserva.get_hora())

##### EJERCICIO 2 ULTIMO REGISTRO DE HISTORIA CLINICA #######

print "Ultima historia clinica del paciente " + paciente1.get_nombre()
ultima_historia = paciente1.buscar_ultima_historia_clinica()
print ultima_historia.get_datos()
